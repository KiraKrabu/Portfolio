import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sqlalchemy
from datetime import datetime, timedelta
from workalendar.europe import Russia
from sklearn import metrics, model_selection
from sklearn.base import clone
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, HistGradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.tree import DecisionTreeRegressor
import xgboost as xgb
from typing import List, Tuple
from sqlalchemy import text
import os 
import joblib

# Конфигурация подключения к БД
DB_CONFIG = {
    #"user": "postgres",
    #"password": "trustme222024", 
    #"host": "127.0.0.1",
    #"port": "5432",
    #"database": "quotes"
    "user": "postgres",
    "password": "trustme", 
    "host": "194.226.121.180",
    "port": "5432",
    "database": "mydb"
}

class StockPredictor:
    # Класс для прогнозирования цен акций с использованием ансамбля моделей
    
    MODELS_DIR = "trained_models"

    def save_model(self, model, name):
        if not os.path.exists(self.MODELS_DIR):
            os.makedirs(self.MODELS_DIR)
        joblib.dump(model, os.path.join(self.MODELS_DIR, f"{name}.pkl"))

    def load_model(self, name):
        path = os.path.join(self.MODELS_DIR, f"{name}.pkl")
        if os.path.exists(path):
            return joblib.load(path)
        return None

    def __init__(self):
        # Иницилизация параметров
        self.calendar = Russia()
        self.models = self._initialize_models()
        self.features = [
            'open_price', 'sma_10', 'net_income', 
            'pe_ratio', 'volume', 'company_sentiment',
            'market_sentiment'
        ]
        self.target = 'close_price'
        
    def _initialize_models(self) -> List[Tuple[str, object]]:
        # Инициализация моделей машинного обучения
        return [
            ("Linear Regression", LinearRegression()),
            ('DecisionTree', DecisionTreeRegressor(criterion='friedman_mse', 
                                                   max_depth=10)),
            ('RandomForest', RandomForestRegressor(n_estimators=100, 
                                                   max_depth=12, min_samples_leaf=2)),
            ('KNN', KNeighborsRegressor(n_neighbors=9,algorithm='ball_tree', 
                                        leaf_size=20, metric='euclidean', 
                                        weights='distance')),
            ('GradientBoosting', GradientBoostingRegressor(n_estimators=50, 
                                                           learning_rate=0.3, 
                                                           criterion='friedman_mse')),
            ('XGBoost', xgb.XGBRegressor(booster='gblinear', objective='reg:squarederror', 
                                         learning_rate=1.0, reg_alpha=0.45, reg_lambda=0.1, 
                                         eval_metric='rmse', 
                                         updater='coord_descent'))
        ]
    
    def train_stacking_model(self, X, y):
        base_preds = []
        for name, model in self.models:
            m = self.load_model(name)
            if m is None:
                m = clone(model)
                m.fit(X, y)
                self.save_model(m, name)
            base_preds.append(m.predict(X).reshape(-1, 1))

        X_meta = np.hstack(base_preds)

        # Загружаем мета-модель, если она уже обучена
        meta_model = self.load_model("MetaModel")
        if meta_model is None:
            meta_model = HistGradientBoostingRegressor()
            meta_model.fit(X_meta, y)
            self.save_model(meta_model, "MetaModel")

        return meta_model
    
    def predict_stacked(self, X):
        base_preds = []
        for name, model in self.models:
            m = self.load_model(name)
            base_preds.append(m.predict(X).reshape(-1, 1))
        X_meta = np.hstack(base_preds)
        meta_model = self.load_model("MetaModel")
        return meta_model.predict(X_meta)

    def load_data(self) -> pd.DataFrame:
        # Загрузка данных из PostgreSQL
        engine = sqlalchemy.create_engine(
            f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@"
            f"{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
        )
        
        query = """
        SELECT q.company_id, q.date, q.open_price, q.close_price,
               q.high_price, q.low_price, q.volume, q.sma_5, q.sma_10, q.sma_20,
               fs.revenue, fs.net_income, fs.total_assets, fs.total_liabilities,
               fr.roe, COALESCE(fr.roa, 0) AS roa, fr.pe_ratio,
               COALESCE(AVG(n.sentiment_score), 0) AS company_sentiment,
               COALESCE(gn.avg_general_sentiment, 0) AS market_sentiment
        FROM quotes q 
        LEFT JOIN LATERAL (
            SELECT *
            FROM financial_statements fs
            WHERE fs.company_id = q.company_id AND fs.date <= q.date
            ORDER BY fs.date DESC
            LIMIT 1
        ) fs ON true 
        LEFT JOIN LATERAL (
            SELECT *
            FROM financial_ratios fr
            WHERE fr.company_id = q.company_id AND fr.date <= q.date
            ORDER BY fr.date DESC
            LIMIT 1
        ) fr ON true 
        LEFT JOIN news n ON q.company_id = n.company_id AND q.date = n.date
        LEFT JOIN (
            SELECT date, AVG(sentiment_score) AS avg_general_sentiment
            FROM general_news
            GROUP BY date
        ) gn ON q.date = gn.date 
        WHERE q.close_price IS NOT NULL 
        GROUP BY
            q.company_id, q.date, q.open_price, q.close_price, q.high_price, q.low_price,
            q.volume, q.sma_5, q.sma_10, q.sma_20,
            fs.revenue, fs.net_income, fs.total_assets, fs.total_liabilities,
            fr.roe, fr.roa, fr.pe_ratio,
            gn.avg_general_sentiment
        ORDER BY q.date;
        """
        
        df = pd.read_sql(query, engine)
        df = self._preprocess_data(df)
        return df
    
    def _preprocess_data(self, df: pd.DataFrame) -> pd.DataFrame:
        # Предварительная обработка данных
        # Заполнение пропущенных значений
        for col in self.features:
            if df[col].isna().any():
                df[col] = df[col].fillna(df[col].median())
        
        # Удаление строк с пропущенными целевыми значениями
        df = df.dropna(subset=[self.target])
        return df
    
    def evaluate_models(self, X: pd.DataFrame, y: pd.Series) -> dict:
        # Оценка моделей с кросс-валидацией временных рядов
        tscv = model_selection.TimeSeriesSplit(n_splits=5)
        metrics_dict = { 
            'mse': [],
            'mae': [],
            'r2': [],
            'mape': []
        }
        
        for train_idx, val_idx in tscv.split(X):
            X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
            y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]
            
            predictions = []
            for name, model in self.models:
                m = clone(model)
                m.fit(X_train, y_train)
                predictions.append(m.predict(X_val))
            
            ensemble_pred = np.mean(predictions, axis=0)
            
            metrics_dict['mse'].append(metrics.mean_squared_error(y_val, ensemble_pred))
            metrics_dict['mae'].append(metrics.mean_absolute_error(y_val, ensemble_pred))
            metrics_dict['r2'].append(metrics.r2_score(y_val, ensemble_pred))
            metrics_dict['mape'].append(np.mean(np.abs((y_val - ensemble_pred) / y_val)) * 100)
        
        return {
            'mean_mse': np.mean(metrics_dict['mse']),
            'mean_mae': np.mean(metrics_dict['mae']),
            'mean_r2': np.mean(metrics_dict['r2']),
            'mean_mape': np.mean(metrics_dict['mape'])
        }
    
    def train_final_models(self, X: pd.DataFrame, y: pd.Series) -> List[object]:
        # Обучение финальных моделей на всех данных
        trained_models = []
        for name, model in self.models:
            m = clone(model)
            m.fit(X, y)
            trained_models.append(m)
        return trained_models
    
    def get_business_days(self, start_date: datetime.date, 
                          n_days: int) -> List[datetime.date]:
        # Получение списка рабочих дней
        business_days = []
        current_date = start_date
        
        while len(business_days) < n_days:
            current_date += timedelta(days=1)
            if self.calendar.is_working_day(current_date):
                business_days.append(current_date)
        
        return business_days
    
    def update_features(self, current_features: pd.Series, predicted_close: float, 
                        current_date: datetime.date) -> pd.Series:
        # Обновление признаков для следующего дня прогноза
        updated = current_features.copy()
        
        # Проверка на приближающиеся праздники
        is_holiday_soon = any(
            not self.calendar.is_working_day(current_date + timedelta(days=d))
            for d in range(1, 4)
        )
        
        # Учет дня недели
        weekday = current_date.weekday()
        volume_multiplier = 1.3 if weekday == 0 else (0.8 if weekday == 4 else 1.0)
        updated['volume'] *= np.random.uniform(0.9, 1.1) * volume_multiplier
        
        # Повышенная волатильность перед праздниками
        if is_holiday_soon:
            updated['volume'] *= np.random.uniform(1.1, 1.4)
        
        # Обновление скользящих средних
        updated['sma_10'] = (current_features['sma_10'] * 9 + predicted_close) / 10
        
        return updated
    
    def forecast_with_ci(self, models: List[object], last_row: pd.Series, 
                         business_days: List[datetime.date], n_iterations: int = 100, 
                         alpha: float = 0.05) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        # Прогноз с доверительными интервалами
        forecast_horizon = len(business_days)
        all_forecasts = np.zeros((n_iterations, forecast_horizon))
        
        for i in range(n_iterations):
            current_features = last_row.copy()
            
            for day in range(forecast_horizon):
                input_df = pd.DataFrame([current_features[self.features]])
                day_preds = [model.predict(input_df)[0] for model in models]
                next_day_pred = np.mean(day_preds)
                
                all_forecasts[i, day] = next_day_pred
                current_features = self.update_features(
                    current_features, 
                    next_day_pred, 
                    business_days[day]
                )
        
        mean_forecast = np.mean(all_forecasts, axis=0)
        lower_bound = np.quantile(all_forecasts, alpha/2, axis=0)
        upper_bound = np.quantile(all_forecasts, 1 - alpha/2, axis=0)
        
        return mean_forecast, lower_bound, upper_bound
    
    
    def analyze_all_companies(self, df: pd.DataFrame) -> dict:
        # Анализ всех компаний в БД
        results = {}
        company_ids = df['company_id'].unique()
        
        # Получение engine для работы с БД
        engine = sqlalchemy.create_engine(
            f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@"
            f"{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
        )
        
        for company_id in company_ids:
            print(f"\nАнализ компании ID: {company_id}")
            try:
                # Подготовка данных для конкретной компании
                target_df = df[df['company_id'] == company_id].copy()
                target_df = target_df.sort_values('date')
                
                if len(target_df) < 10:
                    print(f"Компания {company_id} пропущена - недостаточно данных")
                    continue
                    
                # Получение рабочих дней для прогноза
                last_date = target_df['date'].iloc[-1]
                if hasattr(last_date, 'date'):
                    last_date = last_date.date()
                elif isinstance(last_date, str):
                    last_date = datetime.strptime(last_date, '%Y-%m-%d').date()
                    
                business_days = self.get_business_days(last_date, 20)
                
                # Прогноз с доверительными интервалами
                predictions, lower, upper = self.forecast_with_ci(
                    self.trained_models,
                    target_df.iloc[-1:][self.features].iloc[0],
                    business_days
                )
                
                # Генерация торгового сигнала
                signal, lower_band, upper_band = self.generate_trading_signal(
                    target_df.set_index('date')['close_price']
                )
                
                # Подготовка данных для сохранения в БД
                predictions_data = []
                for i, day in enumerate(business_days):
                    predictions_data.append({
                        'date': day,
                        'predicted_price': predictions[i],
                        'signal': signal,
                        'lower_bound': lower[i],
                        'upper_bound': upper[i]
                    })
                
                # Сохранение в БД
                self.save_predictions_to_db(
                    engine=engine,
                    company_id=company_id,
                    forecast_date=last_date,
                    predictions_data=predictions_data,
                    confidence_level=0.9
                )
                
                # Сохранение результатов для вывода
                results[company_id] = {
                    'signal': signal,
                    'current_price': target_df['close_price'].iloc[-1],
                    'price_range': (lower_band, upper_band),
                    'last_date': last_date
                }
                
                print(f"Торговый сигнал: {signal}")
                print(f"Текущая цена: {target_df['close_price'].iloc[-1]:.2f}")
                
            except Exception as e:
                print(f"Ошибка при анализе компании {company_id}: {str(e)}")
                continue
                
        return results
    
    def generate_trading_signal(self, prices: pd.Series, n_simulations: int = 5000, 
                                hold_days: int = 20, ci_level: float = 0.9) -> Tuple[str, float, float]:
        # Генерация торгового сигнала
        log_returns = np.log(prices / prices.shift(1)).dropna()
        mu, sigma = log_returns.mean(), log_returns.std()
        
        simulated_returns = np.random.normal(
            mu * hold_days,
            sigma * np.sqrt(hold_days),
            n_simulations
        )
        future_prices = prices.iloc[-1] * np.exp(simulated_returns)
        
        lower = np.percentile(future_prices, 100 * (1 - ci_level) / 2)
        upper = np.percentile(future_prices, 100 * (1 + ci_level) / 2)
        
        current_price = prices.iloc[-1]
        if current_price > upper:
            return "SELL", lower, upper
        elif current_price < lower:
            return "BUY", lower, upper
        return "HOLD", lower, upper
    
    def monte_carlo_simulation(self, prices: np.ndarray, n_simulations: int = 1000, 
                               horizon: int = 20) -> np.ndarray:
        # Моделирование методом Монте-Карло
        returns = np.diff(prices) / prices[:-1]
        mu, sigma = np.mean(returns), np.std(returns)
        
        simulations = np.zeros((n_simulations, horizon))
        for i in range(n_simulations):
            price_path = [prices[-1]]
            for _ in range(horizon):
                shock = np.random.normal(mu, sigma)
                price_path.append(price_path[-1] * (1 + shock))
            simulations[i] = price_path[1:]
        
        return simulations
    
    def plot_results(self, business_days: List[datetime.date], predictions: np.ndarray, 
                     lower: np.ndarray, upper: np.ndarray, simulations: np.ndarray = None):
        # Визуализация результатов прогноза
        plt.figure(figsize=(14, 7))
        plt.plot(business_days, predictions, label='Прогноз', marker='o')
        plt.fill_between(
            business_days, lower, upper, 
            color='blue', alpha=0.2, 
            label='90% дов. интервал'
        )
        
        if simulations is not None:
            for path in simulations[:50]:  # Первые 50 траекторий
                plt.plot(business_days, path, color='gray', alpha=0.1)
        
        plt.title('Прогноз цены закрытия с доверительным интервалом')
        plt.xlabel('Дата')
        plt.ylabel('Цена закрытия')
        plt.legend()
        plt.grid(True)
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()

    def save_predictions_to_db(self, engine, company_id: int, forecast_date: datetime, 
                               predictions_data: List[dict], confidence_level: float = 0.9):
        # Сохраняет прогнозы в таблицу predictions с обработкой конфликтов
        
        # SQL-запрос для вставки/обновления данных
        query = """
        INSERT INTO predictions (
            company_id, 
            date, 
            forecast_date, 
            predicted_price, 
            signal, 
            lower_bound, 
            upper_bound, 
            confidence_level
        ) VALUES (
            :company_id,
            :date,
            :forecast_date,
            :predicted_price,
            :signal,
            :lower_bound,
            :upper_bound,
            :confidence_level
        ) 
        ON CONFLICT (company_id, forecast_date) 
        DO UPDATE SET
            predicted_price = EXCLUDED.predicted_price,
            signal = EXCLUDED.signal,
            lower_bound = EXCLUDED.lower_bound,
            upper_bound = EXCLUDED.upper_bound,
            confidence_level = EXCLUDED.confidence_level;
        """
        
        try:
            with engine.connect() as conn:
                # Подготовка данных для вставки
                for day_data in predictions_data:
                    # Явное преобразование numpy-типов в стандартные Python-типы
                    
                    params = {
                        'company_id': int(company_id),  # Преобразуем numpy.int64 в int
                        'date': forecast_date.strftime("%m.%d.%Y"),
                        'forecast_date': day_data['date'].strftime("%m.%d.%Y"),
                        'predicted_price': float(day_data['predicted_price']),
                        'signal': str(day_data['signal']),
                        'lower_bound': float(day_data['lower_bound']),
                        'upper_bound': float(day_data['upper_bound']),
                        'confidence_level': float(confidence_level)
                    }
                    
                    # ВЫполнение запроса
                    conn.execute(sqlalchemy.text(query), params)
                    conn.commit()
                
            print(f"Прогнозы для компании {company_id} успешно сохранены в БД")
            
        except Exception as e:
            print(f"Ошибка при сохранении прогнозов для компании {company_id}: {str(e)}")
            raise

    def analyze_portfolio(self):
        from datetime import date
        engine = sqlalchemy.create_engine(
            f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@"
            f"{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
        )

        # Загрузка данных
        query = """SELECT company_id, date, close_price FROM quotes WHERE close_price IS NOT NULL ORDER BY date;;"""
        df = pd.read_sql(query, engine, parse_dates=['date'], index_col='date')
        df = df.sort_index()

        sber = df[df['company_id'] == 1]['close_price']
        vtb = df[df['company_id'] == 2]['close_price']
        prices = pd.concat([sber, vtb], axis=1)
        prices.columns = ['SBER', 'VTB']
        prices.dropna(inplace=True)

        returns = prices.pct_change().dropna()
        mean_return = returns.mean()
        cov_matrix = returns.cov()

        weights = np.array([0.5, 0.5])
        portfolio_return = np.dot(weights, mean_return)
        portfolio_risk = np.sqrt(weights.T @ cov_matrix @ weights)

        risk_free_rate = 0.08 / 252
        sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_risk
        z_score = 1.28  # 90% доверие
        var = z_score * portfolio_risk
        _lambda = 1
        adj_return = portfolio_return - _lambda * portfolio_risk

        print("\nМетрики портфеля")
        print(f"Доходность (в день): {portfolio_return:.4f}")
        print(f"Риск (в день): {portfolio_risk:.4f}")
        print(f"Sharpe Ratio: {sharpe_ratio:.2f}")
        print(f"Value at Risk (90%): {var:.2%}")
        print(f"Доходность с учетом риска: {adj_return:.2%}")

        today = date.today()
        today = today.strftime("%m.%d.%Y")
        params = {
            'date': today,
            'daily_return': float(portfolio_return),
            'daily_risk': float(portfolio_risk),
            'sharpe_ratio': float(sharpe_ratio),
            'var_90': float(var),
            'expected_return_with_risk': float(adj_return)
        }

        # SQL-запрос
        query = """
        INSERT INTO portfolio_metrics (
            date,
            daily_return,
            daily_risk,
            sharpe_ratio,
            var_90,
            expected_return_with_risk
        ) VALUES (
            :date,
            :daily_return,
            :daily_risk,
            :sharpe_ratio,
            :var_90,
            :expected_return_with_risk
        );
        """

        try:
            with engine.connect() as conn:
                conn.execute(sqlalchemy.text(query), params)
                conn.commit()
                print(f"Метрики портфеля сохранены в БД за {today}")
        except Exception as e:
            print(f"Ошибка при сохранении метрик портфеля: {e}")


def main():
    predictor = StockPredictor()
    
    try:
        # 1. Загрузка данных
        print("Загрузка данных из БД...")
        df = predictor.load_data()
        
        # 2. Подготовка данных
        X = df[predictor.features]
        y = df[predictor.target]
        
        # 3. Оценка моделей
        print("Оценка моделей...")
        metrics = predictor.evaluate_models(X, y)
        print(f"Общие метрики моделей:\n"
              f"MSE: {metrics['mean_mse']:.4f}\n"
              f"MAE: {metrics['mean_mae']:.4f}\n"
              f"R²: {metrics['mean_r2']:.4f}\n"
              f"MAPE: {metrics['mean_mape']:.2f}%")
        
        # 4. Обучение финальных моделей
        print("Обучение финальных моделей...")
        predictor.trained_models = predictor.train_final_models(X, y)
        
        predictor.meta_model = predictor.train_stacking_model(X, y)

        stacked_predictions = predictor.predict_stacked(X)
        print("Прогноз с ансамблем стекинга (первые 5 значений):", stacked_predictions[:5])
        

        # 5. Анализ всех компаний
        print("\nНачинаем анализ всех компаний...")
        results = predictor.analyze_all_companies(df)
        
        # 6. Сводный отчет
        print("\nСводный отчет по всем компаниям:")
        for company_id, data in results.items():
            print(f"\nКомпания ID: {company_id}")
            print(f"Последняя дата: {data['last_date']}")
            print(f"Текущая цена: {data['current_price']:.2f}")
            print(f"Торговый сигнал: {data['signal']}")
            print(f"Прогнозируемый диапазон: [{data['price_range'][0]:.2f}, {data['price_range'][1]:.2f}]")

        # 7. Расчет метрик портфеля
        predictor.analyze_portfolio()
        
    except Exception as e:
        print(f"Критическая ошибка: {str(e)}")
        raise

if __name__ == "__main__":
    main()