import psycopg2
import time
import sys
import os
import subprocess
import threading

DEBOUNCE_SECONDS = 80
timer = None

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from analyze_sentiment import run_sentiment_analysis

def run_pipeline():
    print("Запускается анализ тональности...")
    try:
        run_sentiment_analysis()
    except Exception as e:
        print(f"Ошибка при анализе тональности: {e}")
    
    print("Запускается прогнозирование...")
    try:
        subprocess.run(["python", "forecast.py"], check=True)
    except Exception as e:
        print(f"Ошибка при прогнозировании: {e}")

def on_notification():
    global timer
    if timer and timer.is_alive():
        timer.cancel()
    timer = threading.Timer(DEBOUNCE_SECONDS, run_pipeline)
    timer.start()

# Подключение к БД
conn = psycopg2.connect(
    dbname="mydb",
    user="postgres",
    password="trustme",
    host="194.226.121.180",  # или 'db' в docker-compose
    port="5432"
)
conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
cur = conn.cursor()

cur.execute("LISTEN new_news;")
print("Ожидание новых данных... (CTRL+C для выхода)")

try:
    while True:
        conn.poll()
        while conn.notifies:
            notify = conn.notifies.pop(0)
            print(f"\nПолучено уведомление: {notify.payload}")
            on_notification()
        time.sleep(1)

except KeyboardInterrupt:
    print("Завершение работы.")
finally:
    cur.close()
    conn.close()