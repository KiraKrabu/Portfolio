import re
import torch
import pandas as pd
import numpy as np
from razdel import sentenize
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from sqlalchemy import create_engine, text
from scipy.signal import savgol_filter

# db_user = "postgres"
# db_password = "trustme222024"
# db_host = "127.0.0.1"
# db_host = "host.docker.internal"
# db_port = "5432"
# db_name = "quotes"
db_user = "postgres"
db_password = "trustme"
db_host = "194.226.121.180"
db_port = "5432"
db_name = "mydb"
database_url = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
engine = create_engine(database_url)
print("CONNECTED")

model_checkpoint = 'cointegrated/rubert-tiny-sentiment-balanced'
tokenizer = AutoTokenizer.from_pretrained(model_checkpoint)
model = AutoModelForSequenceClassification.from_pretrained(model_checkpoint)
if torch.cuda.is_available():
    model.cuda()

def clean_text(text: str) -> str:
    # Очищение текста
    text = text.replace('\n', ' ')
    return re.sub(r'\s+', ' ', text).strip()

def estimate_sentiment(sentences: list) -> list:
    # Оценка тональности предложений
    scores = []
    for sentence in sentences:
        with torch.no_grad():
            inputs = tokenizer(sentence, return_tensors='pt', truncation=True, padding=True).to(model.device)
            logits = model(**inputs).logits
            probas = torch.sigmoid(logits).cpu().numpy()[0]
            score = probas.dot([-1, 0, 1])
            scores.append(score)
    return scores

def smooth_sentiments(sentiments: list) -> list:
    # Сглаживание результатов
    window = max(3, len(sentiments) // 15)
    if window % 2 == 0:
        window += 1
    if len(sentiments) < window:
        return sentiments
    return savgol_filter(sentiments, window_length=window, polyorder=0).tolist()

def classify_sentiment(score: float) -> str:
    # Классификация тональности
    if score > 0.33:
        return "positive"
    elif score < -0.33:
        return "negative"
    else:
        return "neutral"

def process_table(table_name: str, id_field: str):
    # Загрузка данных и оценка тональности
    df = pd.read_sql(f"SELECT {id_field}, text FROM {table_name} WHERE sentiment_score IS NULL AND text IS NOT NULL;", engine)

    for _, row in df.iterrows():
        text_id = row[id_field]
        raw_text = row["text"]

        try:
            cleaned = clean_text(raw_text)
            sentences = [s.text for s in sentenize(cleaned)]
            sentiments = estimate_sentiment(sentences)
            smoothed = smooth_sentiments(sentiments)
            overall_score = float(np.mean(smoothed))
            category = classify_sentiment(overall_score)

            update_query = text(f"""
                UPDATE {table_name}
                SET sentiment_score = :score, sentiment_category = :category
                WHERE {id_field} = :id;
            """)
            with engine.begin() as conn:
                result = conn.execute(update_query, {
                    "score": overall_score,
                    "category": category,
                    "id": text_id
                })

            print(f"[{table_name}] Обновлено: ID={text_id}, Score={overall_score:.3f}, Category={category}")

        except Exception as e:
            print(f"Ошибка при обработке {table_name}, ID={text_id}: {e}")

def run_sentiment_analysis():
    # Применение функций к данным названных таблиц
    process_table("news", "news_id")
    process_table("general_news", "news_id")
    engine.dispose()

if __name__ == "__main__":
    run_sentiment_analysis()